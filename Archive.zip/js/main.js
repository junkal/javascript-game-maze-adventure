import { Game } from './game.js';

const game = new Game("gameCanvas", 40, 20, 16);
