
import { Game } from './game.js';
import { CONFIG } from './config.js';

let game = null;
let gameStarted = false;

const startGame = () => {
  // Clear existing game
  if (game) {
    document.getElementById("game-over-overlay").style.display = "none";
    document.getElementById("timer").textContent = `Time Left: ${CONFIG.timeLimit}s`;
  }

  game = new Game("gameCanvas", CONFIG.tileSize, CONFIG.mazeWidth, CONFIG.mazeHeight);
  gameStarted = true;

  // Start music
  const music = document.getElementById("bg-music");
  if (music && music.paused) {
    music.volume = 1.0;
    music.play().catch(() => {});
  }

  // Hide the start overlay if still visible
  const startOverlay = document.getElementById("start-overlay");
  if (startOverlay) startOverlay.style.display = "none";
};

// Trigger start or restart on Enter
document.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    if (!gameStarted || (game && game.gameOver)) {
      startGame();
    }
  }
});